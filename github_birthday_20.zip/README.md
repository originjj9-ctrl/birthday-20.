# Birthday 20 Website 🎂

A mobile-first, multi-screen birthday card website for a 20th birthday.

## Deploy with GitHub Pages

1. Create a new **public** GitHub repository, for example `birthday-20`.
2. Upload **everything in this folder** to the repository root.
3. Make sure `index.html` is directly in the repository root (not inside another folder).
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch **main** and folder **/(root)**, then save.
7. After GitHub finishes publishing, open the Pages URL shown there. It will normally look like:
   `https://YOUR-USERNAME.github.io/birthday-20/`

## Local / SPCK preview

Open `index.html` in SPCK Editor and use Preview/Play.

## Files

- `index.html` — website structure
- `style.css` — design and responsive layout
- `script.js` — screen navigation, swipe controls and confetti
- `images/` — birthday photos
- `.nojekyll` — prevents GitHub Pages from applying Jekyll processing
