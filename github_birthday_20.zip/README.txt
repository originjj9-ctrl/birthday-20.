BIRTHDAY 20 WEBSITE — SPCK READY

The five real photos are already included in the images folder.

PHOTO ARRANGEMENT
photo1.jpg = Screen 2 main portrait
photo2.jpg = Screen 3 tall/left gallery image
photo3.jpg = Screen 3 top-right gallery image
photo4.jpg = Screen 3 bottom-right gallery image
photo5.jpg = Screen 4 feature portrait

FILES
index.html
style.css
script.js
images/photo1.jpg ... photo5.jpg

SPCK
1. Download and extract this ZIP.
2. Open/import the extracted folder in SPCK Editor.
3. Open index.html and use Preview.
4. The photos should appear automatically because they are already inside images/.

GITHUB PAGES
1. Create a public GitHub repository.
2. Upload index.html, style.css, script.js and the images folder.
3. Make sure index.html is at the repository root.
4. Go to Settings > Pages.
5. Select Deploy from a branch, branch main, folder / (root), then Save.
6. GitHub will provide your live website address.

The website is mobile-first and supports buttons, swipe navigation and keyboard arrows.
