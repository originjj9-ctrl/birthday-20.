const screens=[...document.querySelectorAll('.screen')];
const dots=[...document.querySelectorAll('.dot')];
const progress=document.getElementById('progressBar');
let current=0;
let startX=0,startY=0;

function show(n){
  current=Math.max(0,Math.min(screens.length-1,n));
  screens.forEach((s,i)=>s.classList.toggle('active',i===current));
  dots.forEach((d,i)=>d.classList.toggle('active',i===current));
  progress.style.width=((current+1)/screens.length*100)+'%';
  if(current===4) makeConfetti();
}
document.querySelectorAll('[data-next]').forEach(b=>b.addEventListener('click',()=>show(current+1)));
dots.forEach((d,i)=>d.addEventListener('click',()=>show(i)));
document.getElementById('restart').addEventListener('click',()=>show(0));

const card=document.getElementById('card');
card.addEventListener('touchstart',e=>{
  startX=e.changedTouches[0].clientX;
  startY=e.changedTouches[0].clientY;
},{passive:true});
card.addEventListener('touchend',e=>{
  const dx=e.changedTouches[0].clientX-startX;
  const dy=e.changedTouches[0].clientY-startY;
  if(Math.abs(dx)>55 && Math.abs(dx)>Math.abs(dy)) show(current+(dx<0?1:-1));
},{passive:true});

document.addEventListener('keydown',e=>{
  if(e.key==='ArrowRight'||e.key==='ArrowDown')show(current+1);
  if(e.key==='ArrowLeft'||e.key==='ArrowUp')show(current-1);
});

function makeConfetti(){
  const box=document.getElementById('confetti');
  if(box.children.length) return;
  for(let i=0;i<35;i++){
    const el=document.createElement('i');
    el.style.left=Math.random()*100+'%';
    el.style.setProperty('--x',(Math.random()*180-90)+'px');
    el.style.animationDelay=(Math.random()*2.2)+'s';
    el.style.animationDuration=(2.5+Math.random()*2.5)+'s';
    el.style.transform=`rotate(${Math.random()*360}deg)`;
    box.appendChild(el);
  }
}
show(0);
